# Kaduna Life V4
Major gameplay upgrade over V3.

## New systems
- Bank balance
- Properties and home upgrades
- Businesses with levels and daily income
- Career tiers and training
- 9 Kaduna districts
- Travel/time system
- XP, levels and reputation
- Achievements
- Market upgrades
- Persistent local save
- Mobile UI

## Publish
Replace the existing GitHub Pages `index.html` with this V4 file and commit to `main`. The public URL stays the same.

All currency is fictional in-game currency; there are no real-money transactions.
