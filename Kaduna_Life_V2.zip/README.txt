Kaduna Life V2

To update the existing GitHub Pages site:
1. Open the kadunalife.ng repository.
2. Upload this V2 index.html to the repository root.
3. Choose to replace/overwrite the existing index.html.
4. Commit the change directly to main.
5. GitHub Pages will publish the new version automatically.

The same public URL remains:
https://mrkingaz.github.io/kadunalife.ng/

V2 is a single-player static prototype. It uses browser localStorage for saves and contains no real-money transactions.
